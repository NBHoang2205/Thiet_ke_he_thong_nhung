#include "LED.h"

uint8_t LED_DelayMs(uint16_t Time)
{
	HAL_DELAY(Time);
}